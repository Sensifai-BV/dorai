# DoA Quantitative Testing Protocol

The goal of this testing is to move beyond qualitative impressions ("tracks well", "looks good") and gather **quantitative** measurements of the DoA pipeline's accuracy, latency, and resolution. 

**Testing Environment**:
- **Hardware**: ReSpeaker 4-Mic Array
- **Execution**: `python live_doa.py` (perform the walk-around calibration when prompted)

---

## Task 1: Single Stationary Source Accuracy
**Objective**: Measure the absolute angular error of the DoA estimator.

- [ ] **Setup**: Place the ReSpeaker on a table. Measure and mark 4 physical points around the array at a fixed distance (e.g., 1.5 meters) corresponding to exactly `0°`, `90°`, `180°`, and `270°`. 
- [ ] **Action**: Stand at each marked point and speak continuously for 10 seconds. Let the smoothed arrow settle.
- [ ] **Measure**: Record the expected angle vs. the displayed angle in the banner.
  - Expected `0°` -> Measured: _____° (Error: _____°)
  - Expected `90°` -> Measured: _____° (Error: _____°)
  - Expected `180°` -> Measured: _____° (Error: _____°)
  - Expected `270°` -> Measured: _____° (Error: _____°)
- [ ] **Pass criteria**: Absolute error is consistently `≤ 5°` across all angles.

## Task 2: Tracking Latency & Smoothing (The "Filtering" Test)
**Objective**: Determine if the exponential moving average (2.0s time constant) is appropriate for the end-user application.

- [ ] **Setup**: Stand at `0°` and speak continuously until the arrow settles.
- [ ] **Action**: Quickly walk to `90°` while continuing to speak.
- [ ] **Measure**: Observe panel (a) (the smoothed arrow) and panel (c) (the instantaneous scatter plot). 
  - Time for the instantaneous scatter plot to jump to `90°`: _____ seconds
  - Time for the smoothed arrow to fully catch up and settle at `90°`: _____ seconds
- [ ] **Feedback**: Does the 2.0s time constant feel too slow for the target application? (If yes, we can expose `avg_tc` as a CLI argument to tune the tracking speed).

## Task 3: Dual Speaker Resolution 
**Objective**: Verify the SRP-PHAT spectrum can resolve two simultaneous talkers and correctly label the `2nd source`.

- [ ] **Setup**: Two people stand at roughly opposite sides of the array (e.g., `90°` and `270°`), or `90°` and `180°`.
- [ ] **Action**: Both people speak continuously and simultaneously for 10 seconds.
- [ ] **Measure**: Look at panel (b) (the spatial spectrum).
  - Is there a distinct second peak visible on the graph? [Yes/No]
  - Does the `2nd source X°` label appear? [Yes/No]
  - Does the 2nd source label accurately reflect the angle of the second person? [Yes/No]
- [ ] **Pass criteria**: The algorithm correctly identifies and displays both spatial lobes without merging them into a false middle angle.
